package edu.asu.msse.progLngs.runtime;

public class Token {
	
	public int type;
	

}
