package edu.asu.msse.progLngs.runtime.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Instruction {
	
	private String instruction;
	private List values;
	
	public Instruction(String currentLine){
		String[] tokens = currentLine.split(" ");
		instruction = tokens[0];
		values = new ArrayList<String>();
		for(int i=1;i<tokens.length;i++)
			values.add(tokens[i]);
	}
	
	// This function can be called from Runtime.java or execute() of Block class
	public void execute(){
		String keyword = this.getInstruction();
		if(keyword.equals("PRIN")){
			String symbol = this.getValues().get(0).toString();
			System.out.println(RunTime.symbolTable.get(symbol).getTop());
		}
		else if(keyword.equals("STOR")){
			if(null == RunTime.symbolTable.get(this.getValues().get(1))){
				RunTime.symbolTable.put(this.getValues().get(0).toString(),new SymbolTableEntry(this.getValues().get(1).toString()));
			}
			else{
				SymbolTableEntry symbolTableEntry = RunTime.symbolTable.get(this.getValues().get(0));
				symbolTableEntry.push(this.getValues().get(1).toString());
			}
		}
		
	}
	
	public String getInstruction() {
		return instruction;
	}



	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}



	public List getValues() {
		return values;
	}



	public void setValues(List values) {
		this.values = values;
	}

	
}
