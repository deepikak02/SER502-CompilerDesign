package edu.asu.msse.progLngs.runtime;

public enum Type {

	IDENTIFIER,
	INTEGERVALUE,
	STRINGVALUE,
	BOOLVALUE
	
}
