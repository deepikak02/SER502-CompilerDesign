package edu.asu.msse.progLngs.runtime;

public class Value<T> {
	
	private T datatype;
	

}
